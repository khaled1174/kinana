Untrusted inert test data. Do not unpack. Reject ../../escape.txt.
