---
name: safe-skill
description: Benign member in an unsafe archive
---

Inert skill data.
